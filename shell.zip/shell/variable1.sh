#!/bin/bash
#author: sanju
#Purpose: Creating variable
#Usage: ./variable.sh

var1=10
var2="Hello"
echo "Today is $var1 day and $var2 from me today"
echo "is time to have lunch `date`?"
