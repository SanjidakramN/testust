#!/bin/sh
#author: sanju
#Purpose:Learning function with parameter
#Usage:./touch.sh

touch test.txt