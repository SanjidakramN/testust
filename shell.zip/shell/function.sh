#!/bin/sh
#author: sanju
#Purpose:Learning function
#Usage: ./function.sh

function hello{ 
echo "hello world"
}
hello