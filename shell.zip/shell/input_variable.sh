#!/bin/bash
#author: sanju
#Purpose: Reading input from the terminal
#Usage: ./input variable.sh {value1} {value2}
echo "this the first value I got : $1"
echo "this the second value I got : $2"