#!/bin/sh
#author: sanju
#Purpose:Learning basic command 
#Usage:./set.sh


set -x
set `date`
echo "Today is $1"
echo "month is $2"
echo "date is $3"
echo "year is $4"
echo "time is $5"
echo "Am/Pm is $6"

